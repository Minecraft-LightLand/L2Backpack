package dev.xkmc.l2itemselector.select.item;

import dev.xkmc.l2core.serial.config.BaseConfig;
import dev.xkmc.l2core.serial.config.CollectType;
import dev.xkmc.l2core.serial.config.ConfigCollect;
import dev.xkmc.l2core.util.DataGenOnly;
import dev.xkmc.l2itemselector.init.L2ItemSelector;
import dev.xkmc.l2itemselector.init.data.L2ISTagGen;
import dev.xkmc.l2serial.serialization.marker.SerialClass;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@SerialClass
public class SimpleItemSelectConfig extends BaseConfig {

	@Nullable
	public static ItemSelector get(ItemStack stack) {
		SimpleItemSelectConfig config = L2ItemSelector.ITEM_SELECTOR.getMerged();
		return config.find(stack);
	}

	@ConfigCollect(CollectType.MAP_COLLECT)
	@SerialField
	public final HashMap<ResourceLocation, ArrayList<Item>> map = new HashMap<>();

	private HashMap<Item, ItemSelector> cache;

	@Override
	protected void postMerge() {
		cache = new HashMap<>();
		for (var ent : map.entrySet()) {
			ItemSelector sel = new ItemSelector(ent.getKey(), ent.getValue()
					.stream().map(Item::getDefaultInstance)
					.toArray(ItemStack[]::new));
			for (Item item : ent.getValue()) {
				cache.put(item, sel);
			}
		}
	}

	@Nullable
	private ItemSelector find(ItemStack stack) {
		if (!stack.is(L2ISTagGen.SELECTABLE)) return null;
		return cache.get(stack.getItem());
	}

	@DataGenOnly
	public SimpleItemSelectConfig add(ResourceLocation id, Item... items) {
		map.put(id, new ArrayList<>(List.of(items)));
		return this;
	}

}
